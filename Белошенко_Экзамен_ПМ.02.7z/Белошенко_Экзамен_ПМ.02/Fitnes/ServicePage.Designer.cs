﻿namespace Fitnes
{
    partial class ServicePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ServicePage));
            this.fitnesDataSet = new Fitnes.FitnesDataSet();
            this.uslugiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.uslugiTableAdapter = new Fitnes.FitnesDataSetTableAdapters.UslugiTableAdapter();
            this.tableAdapterManager = new Fitnes.FitnesDataSetTableAdapters.TableAdapterManager();
            this.uslugiBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.uslugiBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.uslugiDataGridView = new System.Windows.Forms.DataGridView();
            this.bt_backMainPage = new System.Windows.Forms.Button();
            this.fitnesDataSet2 = new Fitnes.FitnesDataSet2();
            this.sotrudnikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sotrudnikTableAdapter = new Fitnes.FitnesDataSet2TableAdapters.SotrudnikTableAdapter();
            this.tipuslugiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uslugaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodolzhitelnostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDsotrudnikDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fitnesDataSet1 = new Fitnes.FitnesDataSet1();
            this.sotrudnikTableAdapter1 = new Fitnes.FitnesDataSet1TableAdapters.SotrudnikTableAdapter();
            this.tableAdapterManager1 = new Fitnes.FitnesDataSet1TableAdapters.TableAdapterManager();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.fitnesDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uslugiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uslugiBindingNavigator)).BeginInit();
            this.uslugiBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uslugiDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fitnesDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fitnesDataSet1)).BeginInit();
            this.fillByToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // fitnesDataSet
            // 
            this.fitnesDataSet.DataSetName = "FitnesDataSet";
            this.fitnesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // uslugiBindingSource
            // 
            this.uslugiBindingSource.DataMember = "Uslugi";
            this.uslugiBindingSource.DataSource = this.fitnesDataSet;
            // 
            // uslugiTableAdapter
            // 
            this.uslugiTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = Fitnes.FitnesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UslugiTableAdapter = this.uslugiTableAdapter;
            // 
            // uslugiBindingNavigator
            // 
            this.uslugiBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.uslugiBindingNavigator.BindingSource = this.uslugiBindingSource;
            this.uslugiBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.uslugiBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.uslugiBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.uslugiBindingNavigatorSaveItem});
            this.uslugiBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.uslugiBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.uslugiBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.uslugiBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.uslugiBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.uslugiBindingNavigator.Name = "uslugiBindingNavigator";
            this.uslugiBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.uslugiBindingNavigator.Size = new System.Drawing.Size(586, 25);
            this.uslugiBindingNavigator.TabIndex = 0;
            this.uslugiBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // uslugiBindingNavigatorSaveItem
            // 
            this.uslugiBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.uslugiBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("uslugiBindingNavigatorSaveItem.Image")));
            this.uslugiBindingNavigatorSaveItem.Name = "uslugiBindingNavigatorSaveItem";
            this.uslugiBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.uslugiBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.uslugiBindingNavigatorSaveItem.Click += new System.EventHandler(this.uslugiBindingNavigatorSaveItem_Click);
            // 
            // uslugiDataGridView
            // 
            this.uslugiDataGridView.AutoGenerateColumns = false;
            this.uslugiDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.uslugiDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tipuslugiDataGridViewTextBoxColumn,
            this.uslugaDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.prodolzhitelnostDataGridViewTextBoxColumn,
            this.iDsotrudnikDataGridViewTextBoxColumn});
            this.uslugiDataGridView.DataSource = this.uslugiBindingSource;
            this.uslugiDataGridView.Location = new System.Drawing.Point(12, 46);
            this.uslugiDataGridView.Name = "uslugiDataGridView";
            this.uslugiDataGridView.Size = new System.Drawing.Size(548, 329);
            this.uslugiDataGridView.TabIndex = 1;
            // 
            // bt_backMainPage
            // 
            this.bt_backMainPage.Location = new System.Drawing.Point(485, 384);
            this.bt_backMainPage.Name = "bt_backMainPage";
            this.bt_backMainPage.Size = new System.Drawing.Size(75, 23);
            this.bt_backMainPage.TabIndex = 2;
            this.bt_backMainPage.Text = "На главную страницу";
            this.bt_backMainPage.UseVisualStyleBackColor = true;
            this.bt_backMainPage.Click += new System.EventHandler(this.bt_backMainPage_Click);
            // 
            // fitnesDataSet2
            // 
            this.fitnesDataSet2.DataSetName = "FitnesDataSet2";
            this.fitnesDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sotrudnikBindingSource
            // 
            this.sotrudnikBindingSource.DataMember = "Sotrudnik";
            this.sotrudnikBindingSource.DataSource = this.fitnesDataSet2;
            // 
            // sotrudnikTableAdapter
            // 
            this.sotrudnikTableAdapter.ClearBeforeFill = true;
            // 
            // tipuslugiDataGridViewTextBoxColumn
            // 
            this.tipuslugiDataGridViewTextBoxColumn.DataPropertyName = "Tip_uslugi";
            this.tipuslugiDataGridViewTextBoxColumn.HeaderText = "Tip_uslugi";
            this.tipuslugiDataGridViewTextBoxColumn.Name = "tipuslugiDataGridViewTextBoxColumn";
            // 
            // uslugaDataGridViewTextBoxColumn
            // 
            this.uslugaDataGridViewTextBoxColumn.DataPropertyName = "Usluga";
            this.uslugaDataGridViewTextBoxColumn.HeaderText = "Usluga";
            this.uslugaDataGridViewTextBoxColumn.Name = "uslugaDataGridViewTextBoxColumn";
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            // 
            // prodolzhitelnostDataGridViewTextBoxColumn
            // 
            this.prodolzhitelnostDataGridViewTextBoxColumn.DataPropertyName = "Prodolzhitelnost";
            this.prodolzhitelnostDataGridViewTextBoxColumn.HeaderText = "Prodolzhitelnost";
            this.prodolzhitelnostDataGridViewTextBoxColumn.Name = "prodolzhitelnostDataGridViewTextBoxColumn";
            // 
            // iDsotrudnikDataGridViewTextBoxColumn
            // 
            this.iDsotrudnikDataGridViewTextBoxColumn.DataPropertyName = "ID_sotrudnik";
            this.iDsotrudnikDataGridViewTextBoxColumn.HeaderText = "ID_sotrudnik";
            this.iDsotrudnikDataGridViewTextBoxColumn.Name = "iDsotrudnikDataGridViewTextBoxColumn";
            // 
            // fitnesDataSet1
            // 
            this.fitnesDataSet1.DataSetName = "FitnesDataSet1";
            this.fitnesDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sotrudnikTableAdapter1
            // 
            this.sotrudnikTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.UpdateOrder = Fitnes.FitnesDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 25);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(586, 25);
            this.fillByToolStrip.TabIndex = 3;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(39, 22);
            this.fillByToolStripButton.Text = "FillBy";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
            // 
            // ServicePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 427);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.bt_backMainPage);
            this.Controls.Add(this.uslugiDataGridView);
            this.Controls.Add(this.uslugiBindingNavigator);
            this.Name = "ServicePage";
            this.Text = "Услуги";
            this.Load += new System.EventHandler(this.ServicePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fitnesDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uslugiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uslugiBindingNavigator)).EndInit();
            this.uslugiBindingNavigator.ResumeLayout(false);
            this.uslugiBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uslugiDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fitnesDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fitnesDataSet1)).EndInit();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FitnesDataSet fitnesDataSet;
        private System.Windows.Forms.BindingSource uslugiBindingSource;
        private FitnesDataSetTableAdapters.UslugiTableAdapter uslugiTableAdapter;
        private FitnesDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator uslugiBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton uslugiBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView uslugiDataGridView;
        private System.Windows.Forms.Button bt_backMainPage;
        private FitnesDataSet2 fitnesDataSet2;
        private System.Windows.Forms.BindingSource sotrudnikBindingSource;
        private FitnesDataSet2TableAdapters.SotrudnikTableAdapter sotrudnikTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipuslugiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uslugaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodolzhitelnostDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDsotrudnikDataGridViewTextBoxColumn;
        private FitnesDataSet1 fitnesDataSet1;
        private FitnesDataSet1TableAdapters.SotrudnikTableAdapter sotrudnikTableAdapter1;
        private FitnesDataSet1TableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
    }
}