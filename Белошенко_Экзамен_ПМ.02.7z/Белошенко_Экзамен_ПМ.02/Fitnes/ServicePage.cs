﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fitnes
{
    public partial class ServicePage : Form
    {
        public ServicePage()
        {
            InitializeComponent();
            //настраиваем открытие формы по центру экрана
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void ServicePage_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "fitnesDataSet2.Sotrudnik". При необходимости она может быть перемещена или удалена.
            this.sotrudnikTableAdapter.Fill(this.fitnesDataSet2.Sotrudnik);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "fitnesDataSet.Uslugi". При необходимости она может быть перемещена или удалена.
            this.uslugiTableAdapter.Fill(this.fitnesDataSet.Uslugi);



        }

        private void uslugiBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.uslugiBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.fitnesDataSet);

        }

        private void bt_backMainPage_Click(object sender, EventArgs e)
        {
            MainPage mnpg = new MainPage();
            this.Hide();
            mnpg.ShowDialog();
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.sotrudnikTableAdapter1.FillBy(this.fitnesDataSet1.Sotrudnik);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
