﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Fitnes;

namespace Fitnes
{
    public partial class MainPage : Form
    {
        //подключаем класс для взаимодействия с БД
        DataBase database = new DataBase();

        public MainPage()
        {
            InitializeComponent();
            //настраиваем открытие формы по центру экрана
            StartPosition = FormStartPosition.CenterScreen;

        }

        private void bt_reg_Click(object sender, EventArgs e)
        {
            //открываем страницу регистрации
            RegPage rgpg= new RegPage();
            //скрываем главную страницу
            this.Hide();
            //показываем страницу регистрации
            rgpg.ShowDialog();
            

        }

        private void bt_auth_Click(object sender, EventArgs e)
        {
            //открываем страницу авторизвции
            AuthPage auth= new AuthPage();
            //скрываем текущую страницу
            this.Hide();
            //показываем страницу авторизации
            auth.ShowDialog();
            
        }

        private void bt_exit_Click(object sender, EventArgs e)
        {
            //полностью закрываем программу
            this.Close();
        }

        private void bt_service_Click(object sender, EventArgs e)
        {
            //откравыем страницу услуг
            ServicePage svcpg = new ServicePage();
            //скрываем главную страницу
            this.Hide();
            //показываем страницу услуг
            svcpg.ShowDialog();
            
        }
    }
}
