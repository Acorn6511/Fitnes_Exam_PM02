﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Fitnes;

namespace Fitnes
{
    public partial class AuthPage : Form
    {
        //подключаем класс для взаимодействия с БД
        DataBase database = new DataBase();
        public AuthPage()
        {
            InitializeComponent();
            //настраиваем открытие формы по центру экрана
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void AuthPage_Load(object sender, EventArgs e)
        {
            tb_userLogin.MaxLength = 10; //ограничиваем количество вводимых символов в поле логин (по БД 10)
            tb_userPass.MaxLength = 10; //ограничиваем количество вводимых символов в поле пароль (по БД 10)
        }


        private void bt_authUser_Click(object sender, EventArgs e)
        {

            //создаем переменные, куда вносим данные из указанного ТекстБокса
            var UserLogin = tb_userLogin.Text;
            var UserPass = tb_userPass.Text;
            //объявляем 2 объекта класса необходимых для работы с БД
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();
            //создаем строку запроса к БД
            string querystring = $"select ID, Login, Password from Sotrudnik where Login = '{UserLogin}' and Password = '{UserPass}'";
            // создаем объект класса типа Комманд, куда передаем запрос и подключение к БД
            SqlCommand command = new SqlCommand(querystring, database.GetConnection());
            //работаем с адаптером. выполняем команду и заносим данные в таблицу
            adapter.SelectCommand = command;
            adapter.Fill(table);
            //делаем проверку. Если кол-во строк = 1, то вход успешен, иначе-ошибка
            if (table.Rows.Count == 1)
            {
                //выводим сообщение об успешном входе
                MessageBox.Show("Вы успешно вошли!", "Успешно!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //переходим на страницу с услугами
                ServicePage svcpg = new ServicePage();
                // скрываем текущую страницу
                this.Hide();
                // показываем страницу с услугами
                svcpg.ShowDialog();
             
            }
            else
            {
                //выводим сообщение о не верных данных
                MessageBox.Show("Такого аккаунта не существует!", "Аккаунт не существует!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void bt_backMainPage_Click(object sender, EventArgs e)
        {
            //возвращаемся на главную страницу
            MainPage mnpg=new MainPage();
            this.Hide();
            mnpg.ShowDialog();
        }
    }
}
