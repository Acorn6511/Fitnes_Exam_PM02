﻿namespace Fitnes
{
    partial class MainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainPage));
            this.bt_exit = new System.Windows.Forms.Button();
            this.bt_service = new System.Windows.Forms.Button();
            this.bt_reg = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.bt_auth = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_exit
            // 
            this.bt_exit.Location = new System.Drawing.Point(666, 362);
            this.bt_exit.Name = "bt_exit";
            this.bt_exit.Size = new System.Drawing.Size(75, 23);
            this.bt_exit.TabIndex = 0;
            this.bt_exit.Text = "Выход";
            this.bt_exit.UseVisualStyleBackColor = true;
            this.bt_exit.Click += new System.EventHandler(this.bt_exit_Click);
            // 
            // bt_service
            // 
            this.bt_service.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bt_service.Location = new System.Drawing.Point(456, 79);
            this.bt_service.Name = "bt_service";
            this.bt_service.Size = new System.Drawing.Size(274, 23);
            this.bt_service.TabIndex = 1;
            this.bt_service.Text = "Знакомство с услугами клуба";
            this.bt_service.UseVisualStyleBackColor = true;
            this.bt_service.Click += new System.EventHandler(this.bt_service_Click);
            // 
            // bt_reg
            // 
            this.bt_reg.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bt_reg.Location = new System.Drawing.Point(456, 180);
            this.bt_reg.Name = "bt_reg";
            this.bt_reg.Size = new System.Drawing.Size(274, 23);
            this.bt_reg.TabIndex = 2;
            this.bt_reg.Text = "Зарегистрироваться как клиент клуба";
            this.bt_reg.UseVisualStyleBackColor = true;
            this.bt_reg.Click += new System.EventHandler(this.bt_reg_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(218, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(369, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Приветствуем Вас в сети клубов F.I.T.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(-2, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(352, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Предлагаем Вам познакомиться с нашими услугами";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(-2, 290);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(404, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Вы уже наш клиент? Присим Вас авторизоваться в системе";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(-2, 180);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(358, 17);
            this.label6.TabIndex = 8;
            this.label6.Text = "Или Вы можете сразу зарегистрироваться в системе";
            // 
            // bt_auth
            // 
            this.bt_auth.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bt_auth.Location = new System.Drawing.Point(456, 288);
            this.bt_auth.Name = "bt_auth";
            this.bt_auth.Size = new System.Drawing.Size(274, 23);
            this.bt_auth.TabIndex = 9;
            this.bt_auth.Text = "Авторизоваться";
            this.bt_auth.UseVisualStyleBackColor = true;
            this.bt_auth.Click += new System.EventHandler(this.bt_auth_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(-3, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 22);
            this.label3.TabIndex = 5;
            this.label3.Text = "Впервые у нас?";
            // 
            // MainPage
            // 
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(753, 397);
            this.Controls.Add(this.bt_auth);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bt_reg);
            this.Controls.Add(this.bt_service);
            this.Controls.Add(this.bt_exit);
            this.Name = "MainPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_exit;
        private System.Windows.Forms.Button bt_service;
        private System.Windows.Forms.Button bt_reg;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button bt_auth;
        private System.Windows.Forms.Label label3;
    }
}