﻿namespace Fitnes
{
    partial class AuthPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_authUser = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_userLogin = new System.Windows.Forms.TextBox();
            this.lbl_login = new System.Windows.Forms.Label();
            this.lbl_pass = new System.Windows.Forms.Label();
            this.tb_userPass = new System.Windows.Forms.TextBox();
            this.bt_backMainPage = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_authUser
            // 
            this.bt_authUser.Location = new System.Drawing.Point(12, 278);
            this.bt_authUser.Name = "bt_authUser";
            this.bt_authUser.Size = new System.Drawing.Size(231, 23);
            this.bt_authUser.TabIndex = 0;
            this.bt_authUser.Text = "Авторизоваться";
            this.bt_authUser.UseVisualStyleBackColor = true;
            this.bt_authUser.Click += new System.EventHandler(this.bt_authUser_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Авторизация в системе";
            // 
            // tb_userLogin
            // 
            this.tb_userLogin.Location = new System.Drawing.Point(143, 124);
            this.tb_userLogin.Name = "tb_userLogin";
            this.tb_userLogin.Size = new System.Drawing.Size(100, 20);
            this.tb_userLogin.TabIndex = 2;
            // 
            // lbl_login
            // 
            this.lbl_login.AutoSize = true;
            this.lbl_login.Location = new System.Drawing.Point(9, 124);
            this.lbl_login.Name = "lbl_login";
            this.lbl_login.Size = new System.Drawing.Size(81, 13);
            this.lbl_login.TabIndex = 3;
            this.lbl_login.Text = "Введите логин";
            // 
            // lbl_pass
            // 
            this.lbl_pass.AutoSize = true;
            this.lbl_pass.Location = new System.Drawing.Point(9, 200);
            this.lbl_pass.Name = "lbl_pass";
            this.lbl_pass.Size = new System.Drawing.Size(88, 13);
            this.lbl_pass.TabIndex = 4;
            this.lbl_pass.Text = "Введите пароль";
            // 
            // tb_userPass
            // 
            this.tb_userPass.Location = new System.Drawing.Point(143, 193);
            this.tb_userPass.Name = "tb_userPass";
            this.tb_userPass.Size = new System.Drawing.Size(100, 20);
            this.tb_userPass.TabIndex = 5;
            // 
            // bt_backMainPage
            // 
            this.bt_backMainPage.Location = new System.Drawing.Point(12, 321);
            this.bt_backMainPage.Name = "bt_backMainPage";
            this.bt_backMainPage.Size = new System.Drawing.Size(231, 23);
            this.bt_backMainPage.TabIndex = 6;
            this.bt_backMainPage.Text = "На главную страницу";
            this.bt_backMainPage.UseVisualStyleBackColor = true;
            this.bt_backMainPage.Click += new System.EventHandler(this.bt_backMainPage_Click);
            // 
            // AuthPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(253, 365);
            this.Controls.Add(this.bt_backMainPage);
            this.Controls.Add(this.tb_userPass);
            this.Controls.Add(this.lbl_pass);
            this.Controls.Add(this.lbl_login);
            this.Controls.Add(this.tb_userLogin);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bt_authUser);
            this.Name = "AuthPage";
            this.Text = "AuthPage";
            this.Load += new System.EventHandler(this.AuthPage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_authUser;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_userLogin;
        private System.Windows.Forms.Label lbl_login;
        private System.Windows.Forms.Label lbl_pass;
        private System.Windows.Forms.TextBox tb_userPass;
        private System.Windows.Forms.Button bt_backMainPage;
    }
}